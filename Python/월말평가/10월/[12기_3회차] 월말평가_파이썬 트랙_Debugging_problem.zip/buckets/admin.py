from django.contrib import admin
from .models import TravelBucketList

admin.site.register(TravelBucketList)

# Register your models here.
