for T in range(1, int(input())+1): # 테스트 케이스별 반복문 실행
    N = int(input()) # 배열의 길이
    arr = input().strip() # 배열 원소 받아오기
    ans = 1 # 최대 대칭구간의 길이
    for idx in range(1, N-1): # 0과 N-1을 기준으로는 대칭구간을 찾지 않음
        temp, s, t = 1, idx-1, idx+1 # idx를 기준으로 한 대칭 구간의 길이 / 검사할 좌측부분 인덱스, 검사할 우측부분 인덱스
        while s >= 0 and t < N and arr[s] == arr[t]: # 인덱스 범위를 초과하지 않고 좌우가 같은 경우
            temp, s, t = temp+2, s-1, t+1 # 발견한 대칭길이 업데이트/ 다음번에 검사할 좌측 및 우측 인덱스 업데이트
        if ans < temp: ans = temp # idx를 기준으로 한 대칭구간의 길이가 최대 대칭구간의 길이보다 길다면 업데이트
    print(f'#{T} {ans}') # 정답 출력