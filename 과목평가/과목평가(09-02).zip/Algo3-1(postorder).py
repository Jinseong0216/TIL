def postorder(root):
    if edges[root][1]: postorder(edges[root][1])
    if edges[root][2]: postorder(edges[root][2])
    print(edges[root][0])

edges = [[], ['A', 2, 3], ['B', 4, 5], ['C', 6, 7], ['D', 8, 9], ['E', 10, None],
         ['F', None, 13], ['G', 14, 15], ['H', None, None], ['I', None, None],
         ['J', None, None], [None, None, None], [None, None, None], ['K', None, None],
         ['L', None, None], ['M', None, None]]

postorder(3)