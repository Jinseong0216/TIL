for T in range(1, int(input())+1): # 테스트 케이스별 반복문 실행
    N = int(input()) # 문자열의 길이
    char_seq = input().strip() # 암호화 할 문자열 받기
    ans = [] # 암호화 한 문자열을 저장할 리스트
    for c in char_seq:
        b = bin(ord(c))[2:].zfill(8) # 8자리 2진수로 변환
        # 언제나 높이2의 완전 이진트리이고 비트의 저장순서가 언제나 같고 중위순회를 통해 암호화 하므로 아래와 같이 바로 바꾸는 것이 더 빠름
        ans.append(b[-4]+b[-6]+b[-3]+b[-7]+b[-2]+b[-5]+b[-1])
    print(f'#{T}', ' '.join(ans)) # 출력
